export let appState = $state({
    sidebarToggle: false,
    appointments: [],
    homeNotification: false,
    focusAppt: null,
});

let now = new Date();

export let newData = $state(
    {
        clientName: "",
        type: "",
        date: now.getDate(),
        month: now.getMonth(),
        year: now.getFullYear(),
        notes: "",
    }
)


export let color = $state({
  headerColor: "#f8f8f8",
  textColor: "#c9c9c9",
  mainColor: "#018d6c",
  lightMainColor: "#00ad85ff",
  dimMainColor: "#006e55ff",
  grayColor: "#2f2f2f",
  inputColor: "#161616d0",
  bgColor: "#0f0f0f",
  lightBgColor: "#181818",
  lighterBgColor: "#232323",
  lightestBgColor: "#2e2e2e",
  fail: "#a52100"
});

export const darkTheme = {
    headerColor: "#f8f8f8",
    textColor: "#c9c9c9",
    mainColor: "#018d6c",
    lightMainColor: "#00ad85ff",
    dimMainColor: "#006e55ff",
    grayColor: "#2f2f2f",
    inputColor: "#161616d0",
    bgColor: "#0f0f0f",
    lightBgColor: "#181818",
    lighterBgColor: "#232323",
    lightestBgColor: "#2e2e2e",
    fail: "#a52100"
}

export const lightTheme = {
    headerColor: "#020202",
    textColor: "#080808",
    mainColor: "#018d6c",
    lightMainColor: "#00ad85",
    dimMainColor: "#006e55",
    grayColor: "#2f2f2f",
    inputColor: "#bdbdbdd0",
    bgColor: "#f8f8f8",
    lightBgColor: "#e8e8e8",
    lighterBgColor: "#dedede",
    lightestBgColor: "#d1d1d1ff",
    fail: "#a52100"
}


export let settings = $state({
    clock24hr: true,
    darkTheme: true,
    animations: true,
})

export const getRandomItem = (list) => {
  const index = Math.floor(Math.random() * list.length);
  return list[index];
};

export const random = (min, max) => { 
  return Math.floor(Math.random() * (max - min + 1) + min);
}

export const getTimeUntil = (a) => {

    const appointmentDate = new Date(a.year, a.month, a.date, Math.floor(a.time / 60), a.time % 60);
    const now = new Date();
    // ignore this error because it's stupid
    // @ts-ignore
    const diff = (appointmentDate - now) / 60000;

    const daysUntil = diff / 1440;
    const hoursUntil = diff / 60;
    const minutesUntil = diff % 60;
    if((diff + a.duration) < 0){
        appState.homeNotification = true;
        return 'Done';
    }

    if(daysUntil >= 1){
        if(Math.floor(daysUntil) == 1){
            return `In 1 Day`
        } else {
            return `In ${Math.floor(daysUntil)} Days`
        }
    } else if (hoursUntil >= 1){
        if(Math.ceil(hoursUntil) == 1){
            if(minutesUntil > 1){
                return `In ${Math.floor(hoursUntil)} Hour, ${Math.floor(minutesUntil)} Minutes`
            } else if (Math.ceil(minutesUntil) == 1){
                return `In ${Math.floor(hoursUntil)} Hour, 1 Minute`
            } else {
                return `In ${Math.floor(hoursUntil)} Hour`
            }
        } else {
            if(minutesUntil > 1){
                return `In ${Math.floor(hoursUntil)} Hours, ${Math.floor(minutesUntil)} Minutes`
            } else if (Math.ceil(minutesUntil) == 1){
                return `In ${Math.floor(hoursUntil)} Hours, 1 Minute`
            } else {
                return `In ${Math.floor(hoursUntil)} Hours`
            }
        }
    } else if (minutesUntil > 0){
        if(minutesUntil > 2){
            return `In ${Math.ceil(minutesUntil)} Minutes`
        } else {
            return `In ${Math.ceil(minutesUntil)} Minute`
        }
    }
    return `For ${Math.floor(minutesUntil + a.duration)} More Minutes`
}