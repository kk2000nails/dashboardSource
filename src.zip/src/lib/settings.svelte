<script>
    import { settings, color, darkTheme, lightTheme } from "../global.svelte";

    const loadTheme = (theme) => { 
        color.headerColor = theme.headerColor;
        color.textColor = theme.textColor;
        color.mainColor = theme.mainColor;
        color.lightMainColor = theme.lightMainColor;
        color.dimMainColor = theme.dimMainColor;
        color.grayColor = theme.grayColor;
        color.inputColor = theme.inputColor;
        color.bgColor = theme.bgColor;
        color.lightBgColor = theme.lightBgColor;
        color.lighterBgColor = theme.lighterBgColor;
        color.lightestBgColor = theme.lightestBgColor,
        color.fail = theme.fail;
    };


    $effect(() => {
        const colorVars = {
            '--header-color': color.headerColor,
            '--text-color': color.textColor,
            '--main-color': color.mainColor,
            '--light-main-color': color.lightMainColor,
            '--dim-main-color': color.dimMainColor,
            '--gray-color': color.grayColor,
            '--input-color': color.inputColor,
            '--bg-color': color.bgColor,
            '--light-bg-color': color.lightBgColor,
            '--lighter-bg-color': color.lighterBgColor,
            '--lightest-bg-color': color.lightestBgColor,
            '--fail-color': color.fail,
        };

        for (const [varName, value] of Object.entries(colorVars)) {
            document.documentElement.style.setProperty(varName, `${value}`);
        }
    })


</script>

<div class="main">

<div class="headerRow">
    <h1>Settings</h1>
</div>

<div class="settingsMenu">

    <div class="row">
        <div class="text">
            <p class='header'>24 Hour Times</p>
            <p class='content'>Toggle the times to display in military time or standard time.</p>
        </div>

        <label for='toggleClock' class="toggle {settings.animations ? "anims" : ""}" style='{settings.clock24hr ? "background-color: var(--main-color);" : "background-color: var(--lighter-bg-color);"}'>
            <div class="toggleBody {settings.animations ? "anims" : ""}" style='{settings.clock24hr ? "left: calc(100% - 25px);" : "left: 5px;"}'></div>
        </label>

        <button onclick={() => {settings.clock24hr = !settings.clock24hr}} id='toggleClock' class='invis'>Toggle 24HR Time</button>
    </div>

    <div class="row">
        <div class="text">
            <p class='header'>Dark Mode</p>
            <p class='content'>Toggle the UI to be light mode or dark mode.</p>
        </div>

        <label for='toggleTheme' class="toggle {settings.animations ? "anims" : ""}" style='{settings.darkTheme ? "background-color: var(--main-color);" : "background-color: var(--lighter-bg-color);"}'>
            <div class="toggleBody {settings.animations ? "anims" : ""}" style='{settings.darkTheme ? "left: calc(100% - 25px);" : "left: 5px;"}'></div>
        </label>

        <button onclick={() => {
            settings.darkTheme = !settings.darkTheme;
            settings.darkTheme ? loadTheme(darkTheme) : loadTheme(lightTheme);
        }} id='toggleTheme' class='invis'>Toggle 24HR Time</button>
    </div>

    <div class="row">
        <div class="text">
            <p class='header'>Animations</p>
            <p class='content'>Removes animations across the app.</p>
        </div>

        <label for='toggleAnim' class="toggle {settings.animations ? "anims" : ""}" style='{settings.animations ? "background-color: var(--main-color);" : "background-color: var(--lighter-bg-color);"}'>
            <div class="toggleBody {settings.animations ? "anims" : ""}" style='{settings.animations ? "left: calc(100% - 25px);" : "left: 5px;"}'></div>
        </label>

        <button onclick={() => {settings.animations = !settings.animations }} id='toggleAnim' class='invis'>Toggle Animations</button>
    </div>


</div>


</div>


<style>

    .toggle {
        width: 60px;
        height: 30px;
        box-sizing: border-box;
        border-radius: 15px;
        position: relative;
        cursor: pointer;
        margin-top: 5px;
    }

    .toggle.anims {
        transition: background-color .2s ease;
    }

    .toggleBody {
        position: absolute;
        width: 20px;
        top: 5px;
        height: 20px;
        background-color: var(--header-color);
        border-radius: 100%;
    }

    .toggleBody.anims {
        transition: left .2s ease, right .2s ease;
    }

    .text {
        width: 100%;
        height: fit-content;
    }

    .row {
        width: 100%;
        display: flex;
        height: fit-content;
        flex-direction: row;
        justify-content: space-between;
        box-sizing: border-box;
        padding: 10px;
        box-sizing: border-box;
        border-radius: 5px;
    }

    .text .header {
        font-weight: 500;
        font-size: 20px;
        margin: 0px;
        color: var(--header-color);
    }

    .content {
        color: var(--text-color);
    }

    .main {
        place-items: center;
    }

    .settingsMenu {
        width: 100%;
        max-width: 600px;
        display: flex;
        flex-direction: column;
        box-sizing: border-box;
        padding: 10px;

    }

</style>